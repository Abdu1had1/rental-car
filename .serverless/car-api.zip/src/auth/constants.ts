export const jwtConstants = {
    secret: 'xaslkdjasldjalskdjalksdjaslkdjlksajdlkadjsalkd',
  };